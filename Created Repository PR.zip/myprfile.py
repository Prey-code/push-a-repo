import random

my_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
random_list = random.sample(range(1,50), 10)

def print_5th_index():

    print("\n\nprinting the 5th index of my_list:")

    print(my_list[4])